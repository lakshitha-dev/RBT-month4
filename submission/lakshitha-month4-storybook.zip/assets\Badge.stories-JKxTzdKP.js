import{n as e}from"./rolldown-runtime-sJBDdmOt.js";import{n as t}from"./iframe-COI2hS9u.js";import{n,t as r}from"./Badge-CfsDAPtT.js";var i,a,o,s,c;function l(){return(l=e((()=>{n(),i=t(),a={title:`Components/Badge`,component:r,args:{children:`Active`,tone:`success`},argTypes:{tone:{control:`select`,options:[`neutral`,`success`,`warning`,`danger`]}},parameters:{docs:{description:{component:`Status/role label. Always carries text, so meaning never depends on colour alone (WCAG 1.4.1).`}}}},o={},s={render:()=>(0,i.jsxs)(`div`,{className:`flex flex-wrap gap-2`,children:[(0,i.jsx)(r,{children:`Inactive`}),(0,i.jsx)(r,{tone:`success`,children:`Active`}),(0,i.jsx)(r,{tone:`warning`,children:`Pending`}),(0,i.jsx)(r,{tone:`danger`,children:`Deleted`})]})},c=[`Playground`,`AllTones`],o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{}`,...o.parameters?.docs?.source}}},s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  render: () => <div className="flex flex-wrap gap-2">\r
      <Badge>Inactive</Badge>\r
      <Badge tone="success">Active</Badge>\r
      <Badge tone="warning">Pending</Badge>\r
      <Badge tone="danger">Deleted</Badge>\r
    </div>
}`,...s.parameters?.docs?.source}}}})))()}l();export{s as AllTones,o as Playground,c as __namedExportsOrder,a as default};