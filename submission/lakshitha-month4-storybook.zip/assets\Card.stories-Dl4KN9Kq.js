import{n as e}from"./rolldown-runtime-sJBDdmOt.js";import{n as t}from"./iframe-COI2hS9u.js";import{n,t as r}from"./clsx-DSXoiAHx.js";import{n as i,t as a}from"./Button-BtYTVbty.js";function o({className:e,...t}){return(0,u.jsx)(`section`,{className:r(`flex flex-col rounded-card border border-line bg-surface`,e),...t})}function s({title:e,description:t,as:n=`h2`,actions:i,titleId:a,className:o,children:s,...c}){return(0,u.jsxs)(`div`,{className:r(`flex flex-wrap items-start justify-between gap-3 px-5 pt-4`,o),...c,children:[(0,u.jsxs)(`div`,{className:`min-w-0`,children:[e&&(0,u.jsx)(n,{id:a,className:`text-base font-semibold text-ink`,children:e}),t&&(0,u.jsx)(`div`,{className:`mt-0.5 text-sm text-muted`,children:t}),s]}),i&&(0,u.jsx)(`div`,{className:`flex shrink-0 items-center gap-2`,children:i})]})}function c({className:e,...t}){return(0,u.jsx)(`div`,{className:r(`flex-1 px-5 py-4`,e),...t})}function l({className:e,...t}){return(0,u.jsx)(`div`,{className:r(`flex items-center justify-end gap-2 border-t border-rule px-5 py-3`,e),...t})}var u,d;function f(){return(f=e((()=>{n(),u=t(),d=Object.assign(o,{Header:s,Body:c,Footer:l}),o.__docgenInfo={description:`Compound component: <Card><Card.Header /><Card.Body /><Card.Footer /></Card>. A 1px edge, no shadow.`,methods:[],displayName:`CardRoot`}})))()}var p,m,h,g,_,v;function y(){return(y=e((()=>{i(),f(),p=t(),m={title:`Components/Card`,component:d,parameters:{docs:{description:{component:"Compound component: `<Card>` with optional `<Card.Header>`, `<Card.Body>` and `<Card.Footer>`."}}},decorators:[e=>(0,p.jsx)(`div`,{className:`max-w-md`,children:(0,p.jsx)(e,{})})]},h={render:()=>(0,p.jsxs)(d,{children:[(0,p.jsx)(d.Header,{title:`Team plan`,description:`Billed monthly`}),(0,p.jsx)(d.Body,{children:(0,p.jsx)(`p`,{className:`text-sm text-ink`,children:`Up to 25 seats, audit log, SSO and priority support.`})}),(0,p.jsxs)(d.Footer,{children:[(0,p.jsx)(a,{variant:`secondary`,children:`Cancel`}),(0,p.jsx)(a,{children:`Upgrade`})]})]})},g={render:()=>(0,p.jsxs)(d,{children:[(0,p.jsx)(d.Header,{title:`Recent activity`,actions:(0,p.jsx)(a,{size:`sm`,variant:`ghost`,children:`View all`})}),(0,p.jsx)(d.Body,{children:(0,p.jsxs)(`ul`,{className:`space-y-2 text-sm`,children:[(0,p.jsx)(`li`,{children:`Maya Perera created user Liam Khan`}),(0,p.jsx)(`li`,{children:`Ravi Silva updated the role of Uma Rossi`})]})})]})},_={render:()=>(0,p.jsx)(d,{children:(0,p.jsx)(d.Body,{children:(0,p.jsx)(`p`,{className:`text-sm`,children:`A minimal card with only a body.`})})})},v=[`HeaderBodyFooter`,`WithHeaderActions`,`BodyOnly`],h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  render: () => <Card>\r
      <Card.Header title="Team plan" description="Billed monthly" />\r
      <Card.Body>\r
        <p className="text-sm text-ink">\r
          Up to 25 seats, audit log, SSO and priority support.\r
        </p>\r
      </Card.Body>\r
      <Card.Footer>\r
        <Button variant="secondary">Cancel</Button>\r
        <Button>Upgrade</Button>\r
      </Card.Footer>\r
    </Card>
}`,...h.parameters?.docs?.source}}},g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  render: () => <Card>\r
      <Card.Header title="Recent activity" actions={<Button size="sm" variant="ghost">View all</Button>} />\r
      <Card.Body>\r
        <ul className="space-y-2 text-sm">\r
          <li>Maya Perera created user Liam Khan</li>\r
          <li>Ravi Silva updated the role of Uma Rossi</li>\r
        </ul>\r
      </Card.Body>\r
    </Card>
}`,...g.parameters?.docs?.source}}},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  render: () => <Card>\r
      <Card.Body>\r
        <p className="text-sm">A minimal card with only a body.</p>\r
      </Card.Body>\r
    </Card>
}`,..._.parameters?.docs?.source}}}})))()}y();export{_ as BodyOnly,h as HeaderBodyFooter,g as WithHeaderActions,v as __namedExportsOrder,m as default};