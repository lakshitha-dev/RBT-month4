import{n as e}from"./rolldown-runtime-sJBDdmOt.js";import{t}from"./react-pByjoP3I.js";import{n}from"./iframe-COI2hS9u.js";import{n as r,t as i}from"./clsx-DSXoiAHx.js";import{_ as a,r as o}from"./icons-4m0m6-_8.js";import{a as s,o as c,r as l}from"./Input-Cw2AyVUK.js";var u,d,f;function p(){return(p=e((()=>{u=t(),r(),s(),a(),d=n(),f=(0,u.forwardRef)(function({label:e,options:t,error:n,hint:r,hideLabel:a,placeholder:s,id:f,className:p,multiple:m,required:h,...g},_){let v=(0,u.useId)(),y=f??v,b=r||m?`${y}-hint`:void 0,x=n?`${y}-error`:void 0;return(0,d.jsxs)(`div`,{className:p,children:[(0,d.jsxs)(`label`,{htmlFor:y,className:i(c,a&&`sr-only`),children:[e,h&&(0,d.jsx)(`span`,{className:`ml-0.5 text-negative`,"aria-hidden":`true`,children:`*`})]}),(0,d.jsxs)(`div`,{className:`relative`,children:[(0,d.jsxs)(`select`,{ref:_,id:y,multiple:m,required:h,"aria-invalid":n?!0:void 0,"aria-describedby":i(b,x)||void 0,className:i(l(!!n),m?`min-h-28 py-1`:`h-9 appearance-none pr-9`),...g,children:[s&&!m&&(0,d.jsx)(`option`,{value:``,disabled:!0,children:s}),t.map(e=>(0,d.jsx)(`option`,{value:e.value,disabled:e.disabled,children:e.label},e.value))]}),!m&&(0,d.jsx)(o,{className:`pointer-events-none absolute top-1/2 right-3 -translate-y-1/2 text-muted`})]}),(r||m)&&(0,d.jsx)(`p`,{id:b,className:`mt-1.5 text-xs text-muted`,children:r??`Hold Ctrl (Cmd on Mac) or Shift to select multiple options.`}),n&&(0,d.jsx)(`p`,{id:x,className:`mt-1.5 text-xs font-medium text-negative`,children:n})]})}),f.__docgenInfo={description:"Native <select> wrapper: single or multi-select (`multiple`). Native controls give\nscreen-reader and keyboard support for free.",methods:[],displayName:`Select`,props:{label:{required:!0,tsType:{name:`string`},description:``},options:{required:!0,tsType:{name:`Array`,elements:[{name:`SelectOption`}],raw:`SelectOption[]`},description:``},error:{required:!1,tsType:{name:`string`},description:``},hint:{required:!1,tsType:{name:`string`},description:``},hideLabel:{required:!1,tsType:{name:`boolean`},description:``},placeholder:{required:!1,tsType:{name:`string`},description:``}},composes:[`Omit`]}})))()}var m,h,g,_,v,y,b,x;function S(){return(S=e((()=>{p(),m=n(),h={title:`Components/Select`,component:f,args:{label:`Role`,options:[{value:`admin`,label:`Admin`},{value:`editor`,label:`Editor`},{value:`user`,label:`User`}]},decorators:[e=>(0,m.jsx)(`div`,{className:`max-w-sm`,children:(0,m.jsx)(e,{})})]},g={args:{defaultValue:`editor`}},_={args:{placeholder:`Select a role`,defaultValue:``,required:!0}},v={args:{label:`Departments`,multiple:!0,defaultValue:[`Engineering`,`Support`],options:[`Engineering`,`Sales`,`Marketing`,`Support`,`Finance`].map(e=>({value:e,label:e}))}},y={args:{placeholder:`Select a role`,defaultValue:``,error:`Select a role`,required:!0}},b={args:{disabled:!0,defaultValue:`user`}},x=[`Single`,`WithPlaceholder`,`MultiSelect`,`WithError`,`Disabled`],g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  args: {
    defaultValue: 'editor'
  }
}`,...g.parameters?.docs?.source}}},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  args: {
    placeholder: 'Select a role',
    defaultValue: '',
    required: true
  }
}`,..._.parameters?.docs?.source}}},v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{
  args: {
    label: 'Departments',
    multiple: true,
    defaultValue: ['Engineering', 'Support'],
    options: ['Engineering', 'Sales', 'Marketing', 'Support', 'Finance'].map(d => ({
      value: d,
      label: d
    }))
  }
}`,...v.parameters?.docs?.source}}},y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  args: {
    placeholder: 'Select a role',
    defaultValue: '',
    error: 'Select a role',
    required: true
  }
}`,...y.parameters?.docs?.source}}},b.parameters={...b.parameters,docs:{...b.parameters?.docs,source:{originalSource:`{
  args: {
    disabled: true,
    defaultValue: 'user'
  }
}`,...b.parameters?.docs?.source}}}})))()}S();export{b as Disabled,v as MultiSelect,g as Single,y as WithError,_ as WithPlaceholder,x as __namedExportsOrder,h as default};