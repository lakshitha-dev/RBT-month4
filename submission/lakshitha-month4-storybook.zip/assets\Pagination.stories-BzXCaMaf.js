import{n as e}from"./rolldown-runtime-sJBDdmOt.js";import{t}from"./react-pByjoP3I.js";import{n}from"./iframe-COI2hS9u.js";import{n as r,t as i}from"./Pagination-n8VBGobK.js";var a,o,s,c,l,u,d,f,p;function m(){return(m=e((()=>{a=t(),r(),o=n(),{expect:s,fn:c}=__STORYBOOK_MODULE_TEST__,l={title:`Components/Pagination`,component:i,args:{page:1,pageCount:13,pageSize:10,total:124,onPageChange:c()},parameters:{docs:{description:{component:'Labelled `<nav>` with previous/next buttons, a windowed page list and `aria-current="page"` on the current page.'}}}},u={render:e=>{function t(){let[t,n]=(0,a.useState)(e.page);return(0,o.jsx)(i,{...e,page:t,onPageChange:t=>{e.onPageChange(t),n(t)}})}return(0,o.jsx)(t,{})},play:async({canvas:e,userEvent:t,args:n})=>{await s(e.getByRole(`button`,{name:`Previous page`})).toBeDisabled(),await t.click(e.getByRole(`button`,{name:`Next page`})),await s(n.onPageChange).toHaveBeenCalledWith(2),await s(e.getByRole(`button`,{name:`Page 2`})).toHaveAttribute(`aria-current`,`page`)}},d={args:{page:7}},f={args:{page:2,pageCount:3,total:25}},p=[`Interactive`,`MiddlePage`,`FewPages`],u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  render: args => {
    function Demo() {
      const [page, setPage] = useState(args.page);
      return <Pagination {...args} page={page} onPageChange={p => {
        args.onPageChange(p);
        setPage(p);
      }} />;
    }
    return <Demo />;
  },
  play: async ({
    canvas,
    userEvent,
    args
  }) => {
    await expect(canvas.getByRole('button', {
      name: 'Previous page'
    })).toBeDisabled();
    await userEvent.click(canvas.getByRole('button', {
      name: 'Next page'
    }));
    await expect(args.onPageChange).toHaveBeenCalledWith(2);
    await expect(canvas.getByRole('button', {
      name: 'Page 2'
    })).toHaveAttribute('aria-current', 'page');
  }
}`,...u.parameters?.docs?.source}}},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  args: {
    page: 7
  }
}`,...d.parameters?.docs?.source}}},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  args: {
    page: 2,
    pageCount: 3,
    total: 25
  }
}`,...f.parameters?.docs?.source}}}})))()}m();export{f as FewPages,u as Interactive,d as MiddlePage,p as __namedExportsOrder,l as default};