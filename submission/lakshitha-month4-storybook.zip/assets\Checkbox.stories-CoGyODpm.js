import{n as e}from"./rolldown-runtime-sJBDdmOt.js";import{t}from"./react-pByjoP3I.js";import{n}from"./iframe-COI2hS9u.js";import{n as r,t as i}from"./clsx-DSXoiAHx.js";var a,o,s;function c(){return(c=e((()=>{a=t(),r(),o=n(),s=(0,a.forwardRef)(function({label:e,description:t,error:n,id:r,className:s,...c},l){let u=(0,a.useId)(),d=r??u,f=t?`${d}-desc`:void 0,p=n?`${d}-error`:void 0;return(0,o.jsxs)(`div`,{className:i(`flex items-start gap-3`,s),children:[(0,o.jsx)(`input`,{ref:l,id:d,type:`checkbox`,"aria-invalid":n?!0:void 0,"aria-describedby":i(f,p)||void 0,className:`mt-0.5 size-4 shrink-0 accent-primary`,...c}),(0,o.jsxs)(`div`,{children:[(0,o.jsx)(`label`,{htmlFor:d,className:`text-sm font-medium text-ink`,children:e}),t&&(0,o.jsx)(`p`,{id:f,className:`text-sm text-muted`,children:t}),n&&(0,o.jsx)(`p`,{id:p,className:`mt-1 text-xs font-medium text-negative`,children:n})]})]})}),s.__docgenInfo={description:``,methods:[],displayName:`Checkbox`,props:{label:{required:!0,tsType:{name:`string`},description:``},description:{required:!1,tsType:{name:`string`},description:``},error:{required:!1,tsType:{name:`string`},description:``}},composes:[`Omit`]}})))()}var l,u,d,f,p,m,h,g;function _(){return(_=e((()=>{c(),l=n(),{expect:u}=__STORYBOOK_MODULE_TEST__,d={title:`Components/Checkbox`,component:s,args:{label:`Active account`,description:`Inactive users cannot sign in.`},decorators:[e=>(0,l.jsx)(`div`,{className:`max-w-sm`,children:(0,l.jsx)(e,{})})]},f={play:async({canvas:e,userEvent:t})=>{let n=e.getByRole(`checkbox`,{name:`Active account`});await u(n).toHaveAccessibleDescription(`Inactive users cannot sign in.`),await t.click(n),await u(n).toBeChecked()}},p={args:{defaultChecked:!0}},m={args:{label:`I confirm these details are correct`,description:void 0,error:`Please confirm the details are correct`}},h={args:{disabled:!0}},g=[`Default`,`Checked`,`WithError`,`Disabled`],f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  play: async ({
    canvas,
    userEvent
  }) => {
    const box = canvas.getByRole('checkbox', {
      name: 'Active account'
    });
    await expect(box).toHaveAccessibleDescription('Inactive users cannot sign in.');
    await userEvent.click(box);
    await expect(box).toBeChecked();
  }
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  args: {
    defaultChecked: true
  }
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  args: {
    label: 'I confirm these details are correct',
    description: undefined,
    error: 'Please confirm the details are correct'
  }
}`,...m.parameters?.docs?.source}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  args: {
    disabled: true
  }
}`,...h.parameters?.docs?.source}}}})))()}_();export{p as Checked,f as Default,h as Disabled,m as WithError,g as __namedExportsOrder,d as default};