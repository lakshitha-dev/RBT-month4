import{n as e}from"./rolldown-runtime-sJBDdmOt.js";import{n as t}from"./iframe-COI2hS9u.js";import{_ as n,d as r,h as i}from"./icons-4m0m6-_8.js";import{n as a,t as o}from"./Button-BtYTVbty.js";var s,c,l,u,d,f,p,m,h,g,_,v,y,b;function x(){return(x=e((()=>{a(),n(),s=t(),{expect:c,fn:l}=__STORYBOOK_MODULE_TEST__,u={title:`Components/Button`,component:o,args:{children:`Click me`,onClick:l()},argTypes:{variant:{control:`select`,options:[`primary`,`secondary`,`danger`,`ghost`]},size:{control:`inline-radio`,options:[`sm`,`md`,`lg`]},isLoading:{control:`boolean`},disabled:{control:`boolean`}}},d={args:{variant:`primary`},play:async({args:e,canvas:t,userEvent:n})=>{await n.click(t.getByRole(`button`,{name:`Click me`})),await c(e.onClick).toHaveBeenCalledOnce()}},f={args:{variant:`secondary`}},p={args:{variant:`danger`,children:`Delete user`,leftIcon:(0,s.jsx)(i,{})}},m={args:{variant:`ghost`}},h={args:{leftIcon:(0,s.jsx)(r,{}),children:`Add user`}},g={args:{isLoading:!0,children:`Saving…`}},_={args:{disabled:!0}},v={render:e=>(0,s.jsxs)(`div`,{className:`flex flex-wrap items-center gap-3`,children:[(0,s.jsx)(o,{...e,size:`sm`,children:`Small`}),(0,s.jsx)(o,{...e,size:`md`,children:`Medium`}),(0,s.jsx)(o,{...e,size:`lg`,children:`Large`})]})},y={args:{"aria-label":`Delete user Maya Fernando`,variant:`ghost`,children:(0,s.jsx)(i,{})}},b=[`Primary`,`Secondary`,`Danger`,`Ghost`,`WithIcon`,`Loading`,`Disabled`,`Sizes`,`IconOnly`],d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'primary'
  },
  play: async ({
    args,
    canvas,
    userEvent
  }) => {
    await userEvent.click(canvas.getByRole('button', {
      name: 'Click me'
    }));
    await expect(args.onClick).toHaveBeenCalledOnce();
  }
}`,...d.parameters?.docs?.source}}},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'secondary'
  }
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'danger',
    children: 'Delete user',
    leftIcon: <TrashIcon />
  }
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'ghost'
  }
}`,...m.parameters?.docs?.source}}},h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  args: {
    leftIcon: <PlusIcon />,
    children: 'Add user'
  }
}`,...h.parameters?.docs?.source}}},g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  args: {
    isLoading: true,
    children: 'Saving…'
  }
}`,...g.parameters?.docs?.source}}},_.parameters={..._.parameters,docs:{..._.parameters?.docs,source:{originalSource:`{
  args: {
    disabled: true
  }
}`,..._.parameters?.docs?.source}}},v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{
  render: args => <div className="flex flex-wrap items-center gap-3">\r
      <Button {...args} size="sm">Small</Button>\r
      <Button {...args} size="md">Medium</Button>\r
      <Button {...args} size="lg">Large</Button>\r
    </div>
}`,...v.parameters?.docs?.source}}},y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  args: {
    'aria-label': 'Delete user Maya Fernando',
    variant: 'ghost',
    children: <TrashIcon />
  }
}`,...y.parameters?.docs?.source},description:{story:"Icon-only buttons must have an accessible name via `aria-label`.",...y.parameters?.docs?.description}}}})))()}x();export{p as Danger,_ as Disabled,m as Ghost,y as IconOnly,g as Loading,d as Primary,f as Secondary,v as Sizes,h as WithIcon,b as __namedExportsOrder,u as default};