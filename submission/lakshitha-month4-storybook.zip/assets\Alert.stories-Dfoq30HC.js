import{n as e}from"./rolldown-runtime-sJBDdmOt.js";import{n as t}from"./iframe-COI2hS9u.js";import{n,t as r}from"./clsx-DSXoiAHx.js";import{_ as i,g as a,m as o,o as s,s as c,u as l}from"./icons-4m0m6-_8.js";import{n as u,t as d}from"./Button-BtYTVbty.js";function f({variant:e=`info`,title:t,children:n,onDismiss:i,action:a,className:o}){let c=g[e];return(0,p.jsxs)(`div`,{role:e===`error`||e===`warning`?`alert`:`status`,className:r(`flex gap-3 rounded-card p-4 text-sm text-ink`,h[e],o),children:[(0,p.jsx)(c,{className:r(`mt-0.5 size-4 shrink-0`,m[e])}),(0,p.jsxs)(`div`,{className:`min-w-0 flex-1`,children:[(0,p.jsxs)(`span`,{className:`sr-only`,children:[_[e],`: `]}),t&&(0,p.jsx)(`p`,{className:`font-semibold`,children:t}),n&&(0,p.jsx)(`div`,{className:r(t&&`mt-0.5`,`text-ink`),children:n}),a&&(0,p.jsx)(`div`,{className:`mt-3`,children:a})]}),i&&(0,p.jsx)(`button`,{type:`button`,onClick:i,"aria-label":`Dismiss alert`,className:`-m-1 h-fit rounded-control p-1 text-muted hover:text-ink`,children:(0,p.jsx)(s,{})})]})}var p,m,h,g,_;function v(){return(v=e((()=>{n(),i(),p=t(),m={info:`text-accent`,success:`text-positive`,warning:`text-warning`,error:`text-negative`},h={info:`bg-raised`,success:`bg-pill-positive-bg/60`,warning:`bg-pill-warning-bg`,error:`bg-pill-negative-bg/70`},g={info:l,success:o,warning:a,error:c},_={info:`Information`,success:`Success`,warning:`Warning`,error:`Error`},f.__docgenInfo={description:``,methods:[],displayName:`Alert`,props:{variant:{required:!1,tsType:{name:`union`,raw:`'info' | 'success' | 'warning' | 'error'`,elements:[{name:`literal`,value:`'info'`},{name:`literal`,value:`'success'`},{name:`literal`,value:`'warning'`},{name:`literal`,value:`'error'`}]},description:``,defaultValue:{value:`'info'`,computed:!1}},title:{required:!1,tsType:{name:`string`},description:``},children:{required:!1,tsType:{name:`ReactNode`},description:``},onDismiss:{required:!1,tsType:{name:`signature`,type:`function`,raw:`() => void`,signature:{arguments:[],return:{name:`void`}}},description:``},action:{required:!1,tsType:{name:`ReactNode`},description:``},className:{required:!1,tsType:{name:`string`},description:``}}}})))()}var y,b,x,S,C,w,T,E,D,O;function k(){return(k=e((()=>{v(),u(),y=t(),{fn:b}=__STORYBOOK_MODULE_TEST__,x={title:`Components/Alert`,component:f,args:{title:`Heads up`,children:`Something you should know about.`},argTypes:{variant:{control:`select`,options:[`info`,`success`,`warning`,`error`]}},decorators:[e=>(0,y.jsx)(`div`,{className:`max-w-xl`,children:(0,y.jsx)(e,{})})],parameters:{docs:{description:{component:'`error` and `warning` use `role="alert"` (assertive); `info` and `success` use `role="status"` (polite).'}}}},S={args:{variant:`info`,title:`New feature`,children:`You can now export users to CSV.`}},C={args:{variant:`success`,title:`User created`,children:`Nuwan Silva was added as an editor.`}},w={args:{variant:`warning`,title:`Storage at 82%`,children:`Consider archiving old exports.`}},T={args:{variant:`error`,title:`Couldn't load users`,children:`The server did not respond.`,action:(0,y.jsx)(d,{size:`sm`,variant:`secondary`,children:`Retry`})}},E={args:{variant:`info`,onDismiss:b()}},D={render:()=>(0,y.jsxs)(`div`,{className:`space-y-3`,children:[(0,y.jsx)(f,{variant:`info`,title:`Info`,children:`Informational message.`}),(0,y.jsx)(f,{variant:`success`,title:`Success`,children:`Operation completed.`}),(0,y.jsx)(f,{variant:`warning`,title:`Warning`,children:`Check this before continuing.`}),(0,y.jsx)(f,{variant:`error`,title:`Error`,children:`Something went wrong.`})]})},O=[`Info`,`Success`,`Warning`,`Error`,`Dismissible`,`AllVariants`],S.parameters={...S.parameters,docs:{...S.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'info',
    title: 'New feature',
    children: 'You can now export users to CSV.'
  }
}`,...S.parameters?.docs?.source}}},C.parameters={...C.parameters,docs:{...C.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'success',
    title: 'User created',
    children: 'Nuwan Silva was added as an editor.'
  }
}`,...C.parameters?.docs?.source}}},w.parameters={...w.parameters,docs:{...w.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'warning',
    title: 'Storage at 82%',
    children: 'Consider archiving old exports.'
  }
}`,...w.parameters?.docs?.source}}},T.parameters={...T.parameters,docs:{...T.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'error',
    title: "Couldn't load users",
    children: 'The server did not respond.',
    action: <Button size="sm" variant="secondary">Retry</Button>
  }
}`,...T.parameters?.docs?.source}}},E.parameters={...E.parameters,docs:{...E.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'info',
    onDismiss: fn()
  }
}`,...E.parameters?.docs?.source}}},D.parameters={...D.parameters,docs:{...D.parameters?.docs,source:{originalSource:`{
  render: () => <div className="space-y-3">\r
      <Alert variant="info" title="Info">Informational message.</Alert>\r
      <Alert variant="success" title="Success">Operation completed.</Alert>\r
      <Alert variant="warning" title="Warning">Check this before continuing.</Alert>\r
      <Alert variant="error" title="Error">Something went wrong.</Alert>\r
    </div>
}`,...D.parameters?.docs?.source}}}})))()}k();export{D as AllVariants,E as Dismissible,T as Error,S as Info,C as Success,w as Warning,O as __namedExportsOrder,x as default};