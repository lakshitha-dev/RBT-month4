import{n as e}from"./rolldown-runtime-sJBDdmOt.js";import{n as t}from"./iframe-COI2hS9u.js";import{_ as n,f as r}from"./icons-4m0m6-_8.js";import{a as i,t as a}from"./Input-Cw2AyVUK.js";var o,s,c,l,u,d,f,p,m,h;function g(){return(g=e((()=>{i(),n(),o=t(),s={title:`Components/Input`,component:a,args:{label:`Full name`,placeholder:`Maya Fernando`},argTypes:{type:{control:`select`,options:[`text`,`email`,`password`,`search`]}},decorators:[e=>(0,o.jsx)(`div`,{className:`max-w-sm`,children:(0,o.jsx)(e,{})})]},c={},l={args:{label:`Email`,type:`email`,placeholder:`maya.fernando@adminflow.dev`,autoComplete:`email`}},u={args:{label:`Password`,type:`password`,placeholder:void 0,hint:`At least 8 characters.`}},d={args:{label:`Email`,type:`email`,defaultValue:`not-an-email`,error:`Invalid email address`,required:!0}},f={args:{hint:`This is shown to other administrators.`}},p={args:{label:`Search users`,type:`search`,placeholder:`Name or email`,leftIcon:(0,o.jsx)(r,{})}},m={args:{disabled:!0,defaultValue:`Read only value`}},h=[`Text`,`Email`,`Password`,`WithError`,`WithHint`,`WithIcon`,`Disabled`],c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{}`,...c.parameters?.docs?.source}}},l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  args: {
    label: 'Email',
    type: 'email',
    placeholder: 'maya.fernando@adminflow.dev',
    autoComplete: 'email'
  }
}`,...l.parameters?.docs?.source}}},u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  args: {
    label: 'Password',
    type: 'password',
    placeholder: undefined,
    hint: 'At least 8 characters.'
  }
}`,...u.parameters?.docs?.source}}},d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  args: {
    label: 'Email',
    type: 'email',
    defaultValue: 'not-an-email',
    error: 'Invalid email address',
    required: true
  }
}`,...d.parameters?.docs?.source}}},f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  args: {
    hint: 'This is shown to other administrators.'
  }
}`,...f.parameters?.docs?.source}}},p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  args: {
    label: 'Search users',
    type: 'search',
    placeholder: 'Name or email',
    leftIcon: <SearchIcon />
  }
}`,...p.parameters?.docs?.source}}},m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  args: {
    disabled: true,
    defaultValue: 'Read only value'
  }
}`,...m.parameters?.docs?.source}}}})))()}g();export{m as Disabled,l as Email,u as Password,c as Text,d as WithError,f as WithHint,p as WithIcon,h as __namedExportsOrder,s as default};