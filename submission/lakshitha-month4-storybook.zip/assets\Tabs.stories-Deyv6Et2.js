import{n as e}from"./rolldown-runtime-sJBDdmOt.js";import{t}from"./react-pByjoP3I.js";import{n}from"./iframe-COI2hS9u.js";import{n as r,t as i}from"./clsx-DSXoiAHx.js";function a(){let e=(0,u.useContext)(f);if(!e)throw Error(`Tabs.* components must be rendered inside <Tabs>.`);return e}function o({value:e,onValueChange:t,children:n,className:r}){let i=(0,u.useId)();return(0,d.jsx)(f.Provider,{value:{value:e,onValueChange:t,baseId:i},children:(0,d.jsx)(`div`,{className:r,children:n})})}function s({children:e,label:t,className:n,ruled:r=!0}){let a=(0,u.useRef)(null);return(0,d.jsx)(`div`,{ref:a,role:`tablist`,"aria-label":t,onKeyDown:e=>{let t=Array.from(a.current?.querySelectorAll(`[role="tab"]:not([disabled])`)??[]),n=t.indexOf(document.activeElement);if(n===-1)return;let r={ArrowRight:t[(n+1)%t.length],ArrowLeft:t[(n-1+t.length)%t.length],Home:t[0],End:t[t.length-1]}[e.key];r&&(e.preventDefault(),r.focus(),r.click())},className:i(`flex gap-6 overflow-x-auto`,r&&`border-b border-line`,n),children:e})}function c({value:e,children:t,disabled:n}){let{value:r,onValueChange:o,baseId:s}=a(),c=r===e;return(0,d.jsx)(`button`,{type:`button`,role:`tab`,id:p(s,e),"aria-selected":c,"aria-controls":m(s,e),tabIndex:c?0:-1,disabled:n,onClick:()=>o(e),className:i(`-mb-px shrink-0 border-b-2 pt-1 pb-2.5 text-sm whitespace-nowrap transition-colors disabled:opacity-50`,c?`border-ink font-semibold text-ink`:`border-transparent font-medium text-muted hover:border-control hover:text-ink`),children:t})}function l({value:e,children:t,className:n}){let{value:r,baseId:i}=a();return r===e?(0,d.jsx)(`div`,{role:`tabpanel`,id:m(i,e),"aria-labelledby":p(i,e),tabIndex:0,className:n,children:t}):null}var u,d,f,p,m,h;function g(){return(g=e((()=>{u=t(),r(),d=n(),f=(0,u.createContext)(null),p=(e,t)=>`${e}-tab-${t}`,m=(e,t)=>`${e}-panel-${t}`,h=Object.assign(o,{List:s,Tab:c,Panel:l}),o.__docgenInfo={description:`Controlled compound Tabs following the WAI-ARIA tabs pattern:\r
roving tabindex, Arrow/Home/End keys with automatic activation.`,methods:[],displayName:`TabsRoot`,props:{value:{required:!0,tsType:{name:`string`},description:`Controlled selected tab value.`},onValueChange:{required:!0,tsType:{name:`signature`,type:`function`,raw:`(value: string) => void`,signature:{arguments:[{type:{name:`string`},name:`value`}],return:{name:`void`}}},description:``},children:{required:!0,tsType:{name:`ReactNode`},description:``},className:{required:!1,tsType:{name:`string`},description:``}}}})))()}function _({initial:e=`overview`}){let[t,n]=(0,v.useState)(e);return(0,y.jsxs)(`div`,{className:`max-w-lg`,children:[(0,y.jsxs)(h,{value:t,onValueChange:n,children:[(0,y.jsxs)(h.List,{label:`Account sections`,children:[(0,y.jsx)(h.Tab,{value:`overview`,children:`Overview`}),(0,y.jsx)(h.Tab,{value:`security`,children:`Security`}),(0,y.jsx)(h.Tab,{value:`billing`,children:`Billing`})]}),(0,y.jsx)(h.Panel,{value:`overview`,className:`mt-4 rounded-card text-sm text-ink`,children:`Account overview: plan, seats and usage.`}),(0,y.jsx)(h.Panel,{value:`security`,className:`mt-4 rounded-card text-sm text-ink`,children:`Two-factor authentication and active sessions.`}),(0,y.jsx)(h.Panel,{value:`billing`,className:`mt-4 rounded-card text-sm text-ink`,children:`Invoices and payment methods.`})]}),(0,y.jsxs)(`p`,{className:`mt-6 text-xs text-muted`,children:[`Controlled value: `,(0,y.jsx)(`code`,{children:t})]})]})}var v,y,b,x,S,C,w;function T(){return(T=e((()=>{v=t(),g(),y=n(),{expect:b}=__STORYBOOK_MODULE_TEST__,x={title:`Components/Tabs`,component:_,parameters:{docs:{description:{component:"Controlled compound Tabs (`value` + `onValueChange`) implementing the WAI-ARIA tabs pattern: roving tabindex and Arrow / Home / End keys."}}}},S={play:async({canvas:e,userEvent:t})=>{let n=e.getByRole(`tab`,{name:`Overview`});await t.click(n),await t.keyboard(`{ArrowRight}`);let r=e.getByRole(`tab`,{name:`Security`});await b(r).toHaveFocus(),await b(r).toHaveAttribute(`aria-selected`,`true`),await b(e.getByRole(`tabpanel`,{name:`Security`})).toBeVisible(),await t.keyboard(`{End}`),await b(e.getByRole(`tab`,{name:`Billing`})).toHaveAttribute(`aria-selected`,`true`)}},C={args:{initial:`billing`}},w=[`Controlled`,`StartOnBilling`],S.parameters={...S.parameters,docs:{...S.parameters?.docs,source:{originalSource:`{
  play: async ({
    canvas,
    userEvent
  }) => {
    const overview = canvas.getByRole('tab', {
      name: 'Overview'
    });
    await userEvent.click(overview);
    await userEvent.keyboard('{ArrowRight}');
    const security = canvas.getByRole('tab', {
      name: 'Security'
    });
    await expect(security).toHaveFocus();
    await expect(security).toHaveAttribute('aria-selected', 'true');
    await expect(canvas.getByRole('tabpanel', {
      name: 'Security'
    })).toBeVisible();
    await userEvent.keyboard('{End}');
    await expect(canvas.getByRole('tab', {
      name: 'Billing'
    })).toHaveAttribute('aria-selected', 'true');
  }
}`,...S.parameters?.docs?.source}}},C.parameters={...C.parameters,docs:{...C.parameters?.docs,source:{originalSource:`{
  args: {
    initial: 'billing'
  }
}`,...C.parameters?.docs?.source}}}})))()}T();export{S as Controlled,C as StartOnBilling,w as __namedExportsOrder,x as default};