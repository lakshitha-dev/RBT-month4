import{n as e}from"./rolldown-runtime-sJBDdmOt.js";import{t}from"./react-pByjoP3I.js";import{n}from"./iframe-COI2hS9u.js";import{t as r}from"./react-dom-x8aFXeHg.js";import{n as i,t as a}from"./clsx-DSXoiAHx.js";import{_ as o,o as s}from"./icons-4m0m6-_8.js";import{n as c,t as l}from"./Button-BtYTVbty.js";import{a as u,t as d}from"./Input-Cw2AyVUK.js";function f(e){return Array.from(e.querySelectorAll(h)).filter(e=>!e.closest(`[inert], [hidden]`)&&getComputedStyle(e).visibility!==`hidden`)}function p(e,t,n){(0,m.useEffect)(()=>{let r=e.current;if(!t||!r)return;let i=document.activeElement;(n?.current??f(r)[0]??r).focus();let a=e=>{if(e.key!==`Tab`)return;let t=f(r);if(t.length===0){e.preventDefault(),r.focus();return}let n=t[0],i=t[t.length-1],a=document.activeElement;e.shiftKey&&(a===n||a===r)?(e.preventDefault(),i.focus()):!e.shiftKey&&a===i&&(e.preventDefault(),n.focus())};return r.addEventListener(`keydown`,a),()=>{r.removeEventListener(`keydown`,a),i?.isConnected&&i.focus()}},[e,t,n])}var m,h;function g(){return(g=e((()=>{m=t(),h=`a[href],area[href],button:not([disabled]),input:not([disabled]):not([type="hidden"]),select:not([disabled]),textarea:not([disabled]),iframe,[contenteditable="true"],[tabindex]:not([tabindex="-1"])`})))()}function _({open:e,onClose:t,title:n,description:r,children:i,footer:o,size:c=`md`,initialFocus:l,role:u=`dialog`,closeOnOverlayClick:d=!0}){let f=(0,v.useRef)(null),m=(0,v.useId)(),h=(0,v.useId)(),g=(0,v.useRef)(t);return g.current=t,p(f,e,l),(0,v.useEffect)(()=>{if(!e)return;let t=e=>{e.key===`Escape`&&(e.stopPropagation(),g.current())},{overflow:n}=document.body.style;return document.body.style.overflow=`hidden`,document.addEventListener(`keydown`,t),()=>{document.body.style.overflow=n,document.removeEventListener(`keydown`,t)}},[e]),e?(0,y.createPortal)((0,b.jsxs)(`div`,{className:`fixed inset-0 z-50 flex items-end justify-center p-4 sm:items-center`,children:[(0,b.jsx)(`div`,{className:`animate-fade-in absolute inset-0 bg-black/45`,"aria-hidden":`true`,onClick:d?t:void 0}),(0,b.jsxs)(`div`,{ref:f,role:u,"aria-modal":`true`,"aria-labelledby":m,"aria-describedby":r?h:void 0,tabIndex:-1,className:a(`animate-rise-in relative flex max-h-[90vh] w-full flex-col rounded-[12px] border border-line bg-surface shadow-[0_16px_48px_rgb(0_0_0/0.18)]`,x[c]),children:[(0,b.jsxs)(`div`,{className:`flex items-start justify-between gap-4 px-6 pt-5 pb-3`,children:[(0,b.jsxs)(`div`,{children:[(0,b.jsx)(`h2`,{id:m,className:`text-lg font-semibold text-ink`,children:n}),r&&(0,b.jsx)(`div`,{id:h,className:`mt-1 text-sm text-muted`,children:r})]}),(0,b.jsx)(`button`,{type:`button`,onClick:t,"aria-label":`Close dialog`,className:`-mt-1 -mr-2 rounded-control p-2 text-muted hover:bg-raised hover:text-ink`,children:(0,b.jsx)(s,{})})]}),i&&(0,b.jsx)(`div`,{className:`overflow-y-auto px-6 pt-2 pb-5`,children:i}),o&&(0,b.jsx)(`div`,{className:`flex flex-col-reverse gap-2 border-t border-rule px-6 py-4 sm:flex-row sm:justify-end`,children:o})]})]}),document.body):null}var v,y,b,x;function S(){return(S=e((()=>{v=t(),y=r(),i(),g(),o(),b=n(),x={sm:`max-w-sm`,md:`max-w-lg`,lg:`max-w-2xl`}})))()}function C(e){let[t,n]=(0,w.useState)(!1),{triggerLabel:r=`Open dialog`,...i}=e;return(0,T.jsxs)(T.Fragment,{children:[(0,T.jsx)(l,{onClick:()=>n(!0),children:r}),(0,T.jsx)(_,{title:`Dialog title`,...i,open:t,onClose:()=>{i.onClose?.(),n(!1)}})]})}var w,T,E,D,O,k,A,j,M,N,P;function F(){return(F=e((()=>{w=t(),c(),u(),S(),T=n(),{expect:E,fn:D,screen:O,waitFor:k}=__STORYBOOK_MODULE_TEST__,A={title:`Components/Modal`,component:_,args:{open:!1,onClose:D(),title:`Dialog title`},parameters:{docs:{description:{component:"Accessible dialog: rendered in a portal with `aria-modal`, labelled by its title and described by its description. Focus is trapped inside, Esc closes it, and focus returns to the trigger."},story:{inline:!1,iframeHeight:420}}}},j={render:e=>{function t(){let t=(0,w.useRef)(null),[n,r]=(0,w.useState)(!1);return(0,T.jsxs)(T.Fragment,{children:[(0,T.jsx)(l,{variant:`danger`,onClick:()=>r(!0),children:`Delete user`}),(0,T.jsx)(_,{open:n,onClose:()=>{e.onClose(),r(!1)},role:`alertdialog`,size:`sm`,title:`Confirm delete`,description:`Are you sure? Maya Fernando will lose access immediately.`,initialFocus:t,footer:(0,T.jsxs)(T.Fragment,{children:[(0,T.jsx)(l,{ref:t,variant:`secondary`,onClick:()=>r(!1),children:`Cancel`}),(0,T.jsx)(l,{variant:`danger`,onClick:()=>r(!1),children:`Delete`})]})})]})}return(0,T.jsx)(t,{})},play:async({canvas:e,userEvent:t,args:n})=>{let r=e.getByRole(`button`,{name:`Delete user`});await t.click(r);let i=await O.findByRole(`alertdialog`,{name:`Confirm delete`});await E(i).toHaveAccessibleDescription(/are you sure/i),await E(O.getByRole(`button`,{name:`Cancel`})).toHaveFocus(),await t.keyboard(`{Escape}`),await k(()=>E(n.onClose).toHaveBeenCalled()),await E(r).toHaveFocus()}},M={render:()=>(0,T.jsx)(C,{triggerLabel:`Edit profile`,title:`Edit profile`,description:`Changes are saved when you press Save.`,footer:(0,T.jsx)(l,{children:`Save`}),children:(0,T.jsxs)(`div`,{className:`space-y-4`,children:[(0,T.jsx)(d,{label:`Full name`,defaultValue:`Maya Fernando`}),(0,T.jsx)(d,{label:`Email`,type:`email`,defaultValue:`maya.fernando@adminflow.dev`})]})})},N={render:()=>(0,T.jsx)(C,{size:`lg`,title:`Terms of service`,triggerLabel:`Read terms`,children:(0,T.jsx)(`div`,{className:`space-y-3 text-sm`,children:Array.from({length:8},(e,t)=>(0,T.jsxs)(`p`,{children:[`Paragraph `,t+1,`. Long content scrolls inside the dialog body while the header and footer stay visible.`]},t))})})},P=[`ConfirmDelete`,`WithForm`,`Large`],j.parameters={...j.parameters,docs:{...j.parameters?.docs,source:{originalSource:`{
  render: args => {
    function Demo() {
      const cancelRef = useRef<HTMLButtonElement>(null);
      const [open, setOpen] = useState(false);
      return <>\r
          <Button variant="danger" onClick={() => setOpen(true)}>\r
            Delete user\r
          </Button>\r
          <Modal open={open} onClose={() => {
          args.onClose();
          setOpen(false);
        }} role="alertdialog" size="sm" title="Confirm delete" description="Are you sure? Maya Fernando will lose access immediately." initialFocus={cancelRef} footer={<>\r
                <Button ref={cancelRef} variant="secondary" onClick={() => setOpen(false)}>\r
                  Cancel\r
                </Button>\r
                <Button variant="danger" onClick={() => setOpen(false)}>\r
                  Delete\r
                </Button>\r
              </>} />\r
        </>;
    }
    return <Demo />;
  },
  play: async ({
    canvas,
    userEvent,
    args
  }) => {
    const trigger = canvas.getByRole('button', {
      name: 'Delete user'
    });
    await userEvent.click(trigger);
    const dialog = await screen.findByRole('alertdialog', {
      name: 'Confirm delete'
    });
    await expect(dialog).toHaveAccessibleDescription(/are you sure/i);
    await expect(screen.getByRole('button', {
      name: 'Cancel'
    })).toHaveFocus();
    await userEvent.keyboard('{Escape}');
    await waitFor(() => expect(args.onClose).toHaveBeenCalled());
    await expect(trigger).toHaveFocus();
  }
}`,...j.parameters?.docs?.source}}},M.parameters={...M.parameters,docs:{...M.parameters?.docs,source:{originalSource:`{
  render: () => <ModalDemo triggerLabel="Edit profile" title="Edit profile" description="Changes are saved when you press Save." footer={<Button>Save</Button>}>\r
      <div className="space-y-4">\r
        <Input label="Full name" defaultValue="Maya Fernando" />\r
        <Input label="Email" type="email" defaultValue="maya.fernando@adminflow.dev" />\r
      </div>\r
    </ModalDemo>
}`,...M.parameters?.docs?.source}}},N.parameters={...N.parameters,docs:{...N.parameters?.docs,source:{originalSource:`{
  render: () => <ModalDemo size="lg" title="Terms of service" triggerLabel="Read terms">\r
      <div className="space-y-3 text-sm">\r
        {Array.from({
        length: 8
      }, (_, i) => <p key={i}>\r
            Paragraph {i + 1}. Long content scrolls inside the dialog body while the header and footer stay visible.\r
          </p>)}\r
      </div>\r
    </ModalDemo>
}`,...N.parameters?.docs?.source}}}})))()}F();export{j as ConfirmDelete,N as Large,M as WithForm,P as __namedExportsOrder,A as default};